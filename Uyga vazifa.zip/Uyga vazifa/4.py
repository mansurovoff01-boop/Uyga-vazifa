import os
os.system("cls")

with open("Uyga vazifa/ortacha.txt", "r") as file:
    sonlar = file.read()
a = sonlar.split()
yigindi = 0
for i in a:
    yigindi += float(i) / len(a)
print(round(yigindi))
print(yigindi)
