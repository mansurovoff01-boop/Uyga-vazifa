import os
os.system("cls")

with open("Uyga vazifa/qidiruv.txt", "r") as file:
    text = file.read().lower()

soz = input("Soz:").lower()
if text.find(soz) != -1:
    print("Soz faylda bor")
else:
    print("Soz faylda yoq")
