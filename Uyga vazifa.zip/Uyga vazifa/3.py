import os
os.system("cls")

with open("Uyga vazifa/katta.txt", "r") as file:
    text = file.read().title()

with open ("Uyga vazifa/katta1.txt", "w") as file:
    file.write(text)