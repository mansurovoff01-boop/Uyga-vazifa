import os
os.system("cls")

with open("Uyga vazifa/sonlar.txt", "r") as file:
    a = file.read()

sonlar = a.split()

matn = ""

for i in sonlar:
    matn += chr(int(i))
with open("Uyga vazifa/text.txt", "w") as file:
    file.write(matn)